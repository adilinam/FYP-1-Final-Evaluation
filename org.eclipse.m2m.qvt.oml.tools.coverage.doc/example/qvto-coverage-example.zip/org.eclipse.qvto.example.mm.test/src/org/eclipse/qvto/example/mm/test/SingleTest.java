package org.eclipse.qvto.example.mm.test;

import static org.junit.Assert.fail;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.plugin.EcorePlugin;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;
import org.eclipse.m2m.qvt.oml.BasicModelExtent;
import org.eclipse.m2m.qvt.oml.ExecutionContextImpl;
import org.eclipse.m2m.qvt.oml.ExecutionDiagnostic;
import org.eclipse.m2m.qvt.oml.ModelExtent;
import org.eclipse.m2m.qvt.oml.TransformationExecutor;
import org.junit.BeforeClass;
import org.junit.Test;

import abc.AbcPackage;

public class SingleTest {
	
	private static final URI TRANSFORMATION_FILE_URI = 
			URI.createFileURI("C:/Localdata/Eclipse/qvto-coverage/git/sample/org.eclipse.qvto.example/transforms/HelloWorld.qvto"); 
	private static final URI IN_MODEL_PLATFORM_URI = 
			URI.createURI("platform:/resource/org.eclipse.qvto.example.mm.test/instances/in.abc");
	private static final URI OUT_MODEL_PLATFORM_URI = 
			URI.createURI("platform:/resource/org.eclipse.qvto.example.mm.test/instances/out.abc");
	
	@BeforeClass
	static public void setUp() throws Exception {
		// Add project to platform resource URI map
		EcorePlugin.getPlatformResourceMap().put("org.eclipse.qvto.example.mm.test", URI.createFileURI(System.getProperty("user.dir") + '/'));
		
		// Register resource factory for our ABC meta-model
		Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("abc",
				new XMIResourceFactoryImpl());
		// Register package
		AbcPackage.eINSTANCE.eClass();
	}

	@Test
	public void test() {
		// create the input extent with its initial contents
		ResourceSet resourceSet = new ResourceSetImpl();
		Resource inResource = resourceSet.getResource(IN_MODEL_PLATFORM_URI, true);		
		EList<EObject> inObjects = inResource.getContents();
		ModelExtent input = new BasicModelExtent(inObjects);		

		// create an empty output model extent
		ModelExtent output = new BasicModelExtent();

		// setup the execution environment details -> 
		// configuration properties, logger, monitor object etc.
		ExecutionContextImpl context = new ExecutionContextImpl();

		// run the transformation assigned to the executor
		TransformationExecutor executor = new TransformationExecutor(TRANSFORMATION_FILE_URI);
		ExecutionDiagnostic result = executor.execute(context, input, output);

		// In case of success, store the output objects in it's resource and persist the resource
		if(result.getSeverity() == Diagnostic.OK) {
			List<EObject> outObjects = output.getContents();
			ResourceSet resourceSet2 = new ResourceSetImpl();
			Resource outResource = resourceSet2.createResource(OUT_MODEL_PLATFORM_URI);
			outResource.getContents().addAll(outObjects);
			try {
				outResource.save(Collections.emptyMap());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			// Consider the test failed
			fail("Failed to execute the transformation");
		}
	}
}
