/**
 */
package abc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>B</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link abc.B#getB <em>B</em>}</li>
 * </ul>
 * </p>
 *
 * @see abc.AbcPackage#getB()
 * @model
 * @generated
 */
public interface B extends Element {
	/**
	 * Returns the value of the '<em><b>B</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>B</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>B</em>' attribute.
	 * @see #setB(String)
	 * @see abc.AbcPackage#getB_B()
	 * @model
	 * @generated
	 */
	String getB();

	/**
	 * Sets the value of the '{@link abc.B#getB <em>B</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>B</em>' attribute.
	 * @see #getB()
	 * @generated
	 */
	void setB(String value);

} // B
