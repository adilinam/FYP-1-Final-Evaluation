/**
 */
package abc;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>A</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link abc.A#getA <em>A</em>}</li>
 * </ul>
 * </p>
 *
 * @see abc.AbcPackage#getA()
 * @model
 * @generated
 */
public interface A extends Element {
	/**
	 * Returns the value of the '<em><b>A</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>A</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>A</em>' attribute.
	 * @see #setA(String)
	 * @see abc.AbcPackage#getA_A()
	 * @model
	 * @generated
	 */
	String getA();

	/**
	 * Sets the value of the '{@link abc.A#getA <em>A</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>A</em>' attribute.
	 * @see #getA()
	 * @generated
	 */
	void setA(String value);

} // A
